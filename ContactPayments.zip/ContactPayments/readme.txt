-- ContactPayments batch helper --

design as a batch loop

load database connection properties load column size and cutoff from xml

use JDBC rowset with cache

test on Apache Derby
